# Atividade

![image](./source/images/1-AnalisadorLexico-1.png)
![image](./source/images/1-AnalisadorLexico-2.png)
![image](./source/images/1-AnalisadorLexico-3.png)
![image](./source/images/1-AnalisadorLexico-4.png)
![image](./source/images/1-AnalisadorLexico-5.png)
![image](./source/images/1-AnalisadorLexico-6.png)
![image](./source/images/1-AnalisadorLexico-7.png)


# Execução

Para executar o análisador léxico é necessário construir o executavel com o seguinte comando:

```bash
make goianinha
```

Em seguida, é possível executar o programa com o seguinte comando:

```bash
./goianinha.exe arquivo_de_teste
```

Onde `arquivo_de_teste` é o nome do seu arquivo de teste da linguagem *goianinha*.